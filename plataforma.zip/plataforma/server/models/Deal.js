const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Deal = sequelize.define('Deal', {
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  value: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  stage: {
    type: DataTypes.STRING, // 'qualificacao', 'demonstracao', 'proposta', 'negociacao', 'ganho', 'perdido'
    allowNull: false,
    defaultValue: 'qualificacao'
  },
  owner: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'Ana'
  },
  company: {
    type: DataTypes.STRING,
    allowNull: true
  }
});

module.exports = Deal;
