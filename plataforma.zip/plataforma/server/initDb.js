const sequelize = require('./config/database');
const Contact = require('./models/Contact');
const Deal = require('./models/Deal');

async function initDb() {
  try {
    await sequelize.authenticate();
    console.log('Database connection established.');
    
    // Sync models (create tables if they don't exist)
    await sequelize.sync();
    console.log('Database synced.');

    // Seed initial data if empty
    const contactCount = await Contact.count();
    if (contactCount === 0) {
      console.log('Seeding initial contacts...');
      await Contact.bulkCreate([
        { name: 'Bruno Alves', company: 'InovaTech', owner: 'Ana', email: 'bruno@inovatech.com' },
        { name: 'Carla Dias', company: 'SoftSolutions', owner: 'Ana', email: 'carla@softsolutions.com' },
        { name: 'Roberto Lima', company: 'AgroData', owner: 'Carlos', email: 'roberto@agrodata.com' }
      ]);
    }

    const dealCount = await Deal.count();
    if (dealCount === 0) {
      console.log('Seeding initial deals...');
      await Deal.bulkCreate([
        { title: 'Implantação na Empresa Alfa', value: 75000, stage: 'qualificacao', owner: 'Ana', company: 'Empresa Alfa' },
        { title: 'Consultoria de Processos', value: 50000, stage: 'qualificacao', owner: 'Ana', company: 'Beta Corp' },
        { title: 'Expansão de Contrato', value: 90000, stage: 'demonstracao', owner: 'Ana', company: 'InovaTech' },
        { title: 'Licença Premium', value: 12000, stage: 'ganho', owner: 'Ana', company: 'StartUp Z' }
      ]);
    }

    console.log('Seeding complete.');

  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

module.exports = initDb;
