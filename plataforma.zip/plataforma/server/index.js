require('dotenv').config();
const express = require('express');
const cors = require('cors');
const initDb = require('./initDb');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Database
initDb();

// Middleware
app.use(cors());
app.use(express.json());

// Import Routes
const contactsRoutes = require('./routes/contacts');
const dealsRoutes = require('./routes/deals');
const aiRoutes = require('./routes/ai');

// Routes
app.use('/api/contacts', contactsRoutes);
app.use('/api/deals', dealsRoutes);
app.use('/api/ai', aiRoutes);

app.get('/', (req, res) => {
    res.json({ message: 'Birth Hub 360 API is running 🚀' });
});

app.get('/api/status', (req, res) => {
    res.json({ 
        status: 'online', 
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
