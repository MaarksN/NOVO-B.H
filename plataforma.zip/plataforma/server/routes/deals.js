const express = require('express');
const router = express.Router();
const Deal = require('../models/Deal');

// GET /api/deals - Retrieve all deals
router.get('/', async (req, res) => {
  try {
    const deals = await Deal.findAll();
    res.json(deals);
  } catch (error) {
    console.error('Error fetching deals:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// POST /api/deals - Create a new deal
router.post('/', async (req, res) => {
  try {
    const { title, value, stage, owner, company } = req.body;
    
    if (!title || value === undefined) {
      return res.status(400).json({ error: 'Title and Value are required' });
    }

    const newDeal = await Deal.create({
      title,
      value,
      stage: stage || 'qualificacao',
      owner: owner || 'Ana',
      company: company || ''
    });

    res.status(201).json(newDeal);
  } catch (error) {
    console.error('Error creating deal:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// PATCH /api/deals/:id - Update deal (e.g., move stage)
router.patch('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        
        const deal = await Deal.findByPk(id);
        if (!deal) {
            return res.status(404).json({ error: 'Deal not found' });
        }

        await deal.update(updates);
        res.json(deal);
    } catch (error) {
        console.error('Error updating deal:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

module.exports = router;
