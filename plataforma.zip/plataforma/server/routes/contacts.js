const express = require('express');
const router = express.Router();
const Contact = require('../models/Contact');

// GET /api/contacts - Retrieve all contacts
router.get('/', async (req, res) => {
  try {
    const contacts = await Contact.findAll();
    res.json(contacts);
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// POST /api/contacts - Create a new contact
router.post('/', async (req, res) => {
  try {
    const { name, company, email, phone, owner } = req.body;
    
    if (!name || !company) {
      return res.status(400).json({ error: 'Name and Company are required' });
    }

    const newContact = await Contact.create({
      name,
      company,
      email,
      phone,
      owner: owner || 'Ana'
    });

    res.status(201).json(newContact);
  } catch (error) {
    console.error('Error creating contact:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
